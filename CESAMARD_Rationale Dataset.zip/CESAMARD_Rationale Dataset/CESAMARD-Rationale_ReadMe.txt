Paper Title:  AbCoRD: Exploiting Multimodal Generative Approach for Aspect-based Complaint and Rationale Detection
    
Conference: ACM Multimedia (ACM MM) 2023

Dataset: Aspect-level Complaint Rationale annotated dataset for Multimodal Aspect-Based Complaint Dataset (CESAMARD-Rationale)


Description: The CESAMARD-Rationale consists of 3962 multimodal complaint reviews (texts and images) in English. Each record in the dataset consists of review text, review image (user-uploaded) domain, review title, complaint labels (overall), aspect categories, aspect-level complaint/non-complaint labels and corresponding annotations for causal spans or rationales for aspect-level complaint instances. For non-complaint instances there are no rationales (Nan).


There are two classes for the Complaint task, i.e, 0: non-complaints and 1: complaints. 


For the aspect category task following are the classes corresponding to each domain:

Books: Content, Packaging, Price, Quality

Edibles: Taste, Smell, Packaging, Price, Quality

Electronics: Design, Software, Hardware, Packaging, Price, Quality

Fashion: Colour, Style, Fit, Packaging, Price, Quality

Miscellaneous: Packaging, Price, Quality

All domains share three common aspect categories, namely packaging, price, and quality because these aspects are relevant for products purchased online.

Follwing were the Annotation guidelines for CESAMARD-Rationale dataset:

1. Rationale should consider the complainant's perspective. 
2. Rationale should imply aspect-level complaint labeled instances only.
3. Rationale annotation should be marked in the same speech form as used in the instance. 
4. Rationale for aspect-level non-complaint instances should  be marked as No cause. 
5. Each rationale should refer to a single aspect.
6. Erroneous labels if found should be reported and rectified.


In the csv file following are the dependencies:

Packaging = packaging+ service labels in the dataset (for all the domains)     
 
For Fashion domain: Quality= quality+fabric+category+texture; fit= fit+shape


